

char *inttostr(entier);

void genclock(int pas, char* clock, int high, int N);