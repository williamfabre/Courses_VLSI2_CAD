#!/bin/bash
eval `/soc/coriolis2/etc/coriolis2/coriolisEnv.py`
cgt -V --cell=cordic_cor
