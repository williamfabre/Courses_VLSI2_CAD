#!/bin/bash
blif2vst --cell=cordic_cor
