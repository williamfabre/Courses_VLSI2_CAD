#Pour ajouter la cell

> File ==>> import cell ==>> nom.blif

#Pour effectuer le placement, sélectionnez dans les menus:

> P&R ==>> Place Block

#Pour effectuer le routage, sélectionnez dans les menus:

> P&R ==>> Route


